import { Favorite } from "./favorite";

export const Favorites: Favorite[]=[];