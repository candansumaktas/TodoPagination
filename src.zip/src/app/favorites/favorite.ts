import { Album } from "../album/album";

export interface Favorite{
    album:Album;
    quantity:number
} 